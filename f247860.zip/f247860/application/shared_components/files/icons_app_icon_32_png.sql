prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 247860
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>41743198632149102545
,p_default_application_id=>247860
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SUMMERTKRITI'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000A1494441545847633C1531F73FC30002C651078C86C068088C86C0A00F81370C9F19F82485197E31FD6190D092C728335F5C7B';
wwv_flow_imp.g_varchar2_table(2) := 'C8C0F68F056B59FAF9F97B0661066EBCE52CC192F015CB67060151F21CF0E1CD3B06B1DF3C9439E097042B8394A602C30FD63F0C8ABE461886DDDF748E81E30FF6107876E32103DBF35F43DC01A351301A02039E0B46A360C08B625A379809D605A30E18';
wwv_flow_imp.g_varchar2_table(3) := '0D81D110180D015A870000CF6FE5E13F8DF8F10000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(43092790508238108136)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
